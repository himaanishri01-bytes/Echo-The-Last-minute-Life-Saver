import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const InputSchema = z.object({ utterance: z.string().min(1).max(500) });

type Parsed = {
  title: string;
  column: "red" | "yellow" | "green";
  meta: string;
};

// Text-to-task: uses Lovable AI Gateway (no user key required) to extract a
// structured task from a natural-language utterance.
export const parseUtterance = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => InputSchema.parse(data))
  .handler(async ({ data }): Promise<Parsed> => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) {
      // Graceful fallback so the dashboard still works without the gateway.
      return { title: data.utterance, column: "red", meta: "Captured" };
    }

    const system = `You are Echo, a priority-matrix parser. Given a user utterance, return STRICT JSON only:
{"title": string (<=80 chars, action-oriented),
 "column": "red" | "yellow" | "green",
 "meta": string (<=60 chars, includes any time/date you detected, or energy window)}
Use "red" for non-negotiable / deadline-bound items, "yellow" for energy-gated tasks, "green" for side quests / hobbies.`;

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: system },
          { role: "user", content: data.utterance },
        ],
        response_format: { type: "json_object" },
      }),
    });

    if (!res.ok) {
      return { title: data.utterance, column: "red", meta: "Captured" };
    }
    const json = (await res.json()) as {
      choices: { message: { content: string } }[];
    };
    try {
      const parsed = JSON.parse(json.choices[0].message.content) as Parsed;
      return {
        title: String(parsed.title).slice(0, 80) || data.utterance,
        column: (["red", "yellow", "green"] as const).includes(parsed.column)
          ? parsed.column
          : "red",
        meta: String(parsed.meta ?? "").slice(0, 60) || "Captured",
      };
    } catch {
      return { title: data.utterance, column: "red", meta: "Captured" };
    }
  });
