import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Brain, LayoutGrid, ShieldCheck, ArrowRight } from "lucide-react";
import { GlassCard } from "@/components/echo/GlassCard";
import { Footer } from "@/components/echo/Footer";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ECHO — Resonant AI Productivity Companion" },
      { name: "description", content: "Echo turns operational chaos into calm execution pathways with empathetic AI." },
    ],
  }),
  component: Home,
});

const features = [
  {
    icon: Brain,
    title: "Zero-Form Input Engine",
    desc: "Speak or type naturally. Echo extracts dates, entities, and intent — no forms, no friction.",
  },
  {
    icon: LayoutGrid,
    title: "Dynamic Priority Matrix",
    desc: "Non-Negotiables, Energy-Gated, and Side Quests. Tuned to how your mind actually works.",
  },
  {
    icon: ShieldCheck,
    title: "The Anti-Doubt Vault",
    desc: "When the slump hits, Echo replays your proven wins. Confidence on demand.",
  },
];

function Home() {
  const navigate = useNavigate();
  return (
    <div className="mx-auto max-w-7xl px-6 pb-20 pt-24">
      <section className="mx-auto max-w-4xl text-center">
        <span className="inline-flex items-center gap-2 rounded-full border border-cyan-400/30 bg-cyan-400/10 px-4 py-1.5 text-xs font-medium uppercase tracking-[0.25em] text-cyan-300">
          Resonance · v1.0
        </span>
        <h1 className="mt-8 text-balance text-5xl font-bold leading-[1.05] tracking-tight text-slate-50 md:text-7xl">
          In the midst of chaos, your{" "}
          <span className="bg-gradient-to-r from-pink-500 via-orange-400 to-violet-500 bg-clip-text text-transparent">
            resilience echoes
          </span>{" "}
          louder than the deadline.
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-pretty text-lg leading-relaxed text-slate-400">
          Echo is an empathetic AI companion built for the last-minute moments. It absorbs operational
          friction, defends your time, and converts pressure into calm, structured execution pathways.
        </p>
        <div className="mt-10 flex items-center justify-center gap-4">
          <button
            onClick={() => navigate({ to: "/auth" })}
            className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 px-7 py-3.5 text-sm font-semibold text-slate-950 shadow-[0_0_45px_-5px_rgba(34,211,238,0.7)] transition-all hover:shadow-[0_0_60px_-2px_rgba(34,211,238,0.9)]"
          >
            Launch Workspace
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
          </button>
          <button
            onClick={() => navigate({ to: "/features" })}
            className="rounded-full border border-slate-700 px-7 py-3.5 text-sm font-semibold text-slate-200 transition-colors hover:border-cyan-400/60 hover:text-cyan-200"
          >
            Explore Features
          </button>
        </div>
      </section>

      <section className="mt-28 grid gap-6 md:grid-cols-3">
        {features.map((f) => (
          <GlassCard key={f.title} className="p-7">
            <f.icon className="h-7 w-7 text-cyan-300" />
            <h3 className="mt-5 text-lg font-semibold text-slate-100">{f.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-slate-400">{f.desc}</p>
          </GlassCard>
        ))}
      </section>

      <Footer />
    </div>
  );
}
