import { createFileRoute } from "@tanstack/react-router";
import { Cpu, CalendarClock, Layers } from "lucide-react";
import { GlassCard } from "@/components/echo/GlassCard";

export const Route = createFileRoute("/features")({
  head: () => ({ meta: [{ title: "Features — ECHO" }] }),
  component: Features,
});

const sections = [
  {
    icon: Cpu,
    title: "Natural Language Tokenization",
    body: "Echo's parser tokenizes unstructured speech and text into entities, intents, and binding metadata using a layered transformer pipeline tuned for short, fragmented productivity input.",
    metrics: [
      ["Avg. tokens / utterance", "18.4"],
      ["Entity extraction F1", "0.94"],
      ["Intent latency (p95)", "212 ms"],
    ],
  },
  {
    icon: CalendarClock,
    title: "Relative Date Parsing",
    body: "Phrases like 'next Friday', 'in two weeks', or 'after lunch tomorrow' resolve against the user's current calendar context, timezone, and previously scheduled blocks.",
    metrics: [
      ["Supported locales", "32"],
      ["Resolution accuracy", "98.7%"],
      ["Conflict avoidance", "Auto"],
    ],
  },
  {
    icon: Layers,
    title: "Prompt Context Windows",
    body: "Each conversation carries a rolling semantic window. Echo stitches clarifications, references, and attached media into coherent task schemas without redundant re-prompts.",
    metrics: [
      ["Context window", "128k tokens"],
      ["Recall after 24h", "91%"],
      ["Vault retrieval", "Vector kNN"],
    ],
  },
];

function Features() {
  return (
    <div className="mx-auto max-w-6xl px-6 pb-24 pt-16">
      <header className="max-w-2xl">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-cyan-300">Technical deep-dive</p>
        <h1 className="mt-3 text-4xl font-bold tracking-tight text-slate-50 md:text-5xl">
          Under the hood of Echo
        </h1>
        <p className="mt-4 text-slate-400">
          How natural language becomes defended calendar time — the orchestration layer in detail.
        </p>
      </header>

      <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {sections.map((s) => (
          <GlassCard key={s.title} className="flex flex-col p-7">
            <s.icon className="h-7 w-7 text-cyan-300" />
            <h2 className="mt-5 text-lg font-semibold text-slate-100">{s.title}</h2>
            <p className="mt-2 flex-1 text-sm leading-relaxed text-slate-400">{s.body}</p>
            <dl className="mt-5 space-y-2 border-t border-slate-800/80 pt-4">
              {s.metrics.map(([k, v]) => (
                <div key={k} className="flex items-center justify-between text-xs">
                  <dt className="text-slate-500">{k}</dt>
                  <dd className="font-mono text-cyan-200">{v}</dd>
                </div>
              ))}
            </dl>
          </GlassCard>
        ))}
      </div>
    </div>
  );
}
