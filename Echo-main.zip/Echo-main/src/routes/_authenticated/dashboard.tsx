import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Mic, MicOff, Send, ChevronDown, AlertTriangle, X, Sparkles, Loader2, Code2 } from "lucide-react";
import { GlassCard } from "@/components/echo/GlassCard";
import { supabase } from "@/integrations/supabase/client";
import { parseUtterance } from "@/lib/echo-ai.functions";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — ECHO" }] }),
  component: Dashboard,
});

type Column = "red" | "yellow" | "green";
type Task = { id: string; title: string; column: Column; meta: string | null };

const columnConfig: Record<
  Column,
  {
    dot: string;
    label: string;
    accent: string;
    section: string;
    card: string;
    meta: string;
    snooze: string;
  }
> = {
  red: {
    dot: "🔴",
    label: "Non-Negotiables",
    accent: "text-pink-300",
    section:
      "border-rose-500/40 bg-gradient-to-br from-rose-950/60 via-[#2a0a18]/70 to-rose-900/30",
    card: "border-rose-500/30 bg-rose-950/30 hover:border-pink-400/70 hover:shadow-[0_0_45px_-10px_rgba(244,63,94,0.55)]",
    meta: "text-pink-300/80",
    snooze: "text-pink-300 hover:text-pink-200",
  },
  yellow: {
    dot: "🟡",
    label: "When I Have Energy",
    accent: "text-orange-300",
    section:
      "border-orange-500/40 bg-gradient-to-br from-violet-950/60 via-[#1f0f3a]/70 to-purple-900/30",
    card: "border-orange-400/30 bg-violet-950/30 hover:border-orange-400/70 hover:shadow-[0_0_45px_-10px_rgba(249,115,22,0.55)]",
    meta: "text-orange-300/80",
    snooze: "text-orange-300 hover:text-orange-200",
  },
  green: {
    dot: "🟢",
    label: "Side Quests",
    accent: "text-emerald-300",
    section:
      "border-emerald-500/40 bg-gradient-to-br from-emerald-950/60 via-[#06231a]/70 to-green-900/20",
    card: "border-emerald-400/30 bg-emerald-950/30 hover:border-emerald-400/70 hover:shadow-[0_0_45px_-10px_rgba(16,185,129,0.55)]",
    meta: "text-emerald-300/80",
    snooze: "text-emerald-300 hover:text-emerald-200",
  },
};

// Temporal cues that mean an utterance is concrete enough to file immediately.
const TEMPORAL_RE =
  /\b(\d{1,2}\s*(?:am|pm)|am|pm|today|tomorrow|tonight|tmrw|monday|tuesday|wednesday|thursday|friday|saturday|sunday|mon|tue|wed|thu|fri|sat|sun|next week|this week|weekend|morning|evening|afternoon|noon|midnight|at\s+\d|by\s+\w|before\s+\w|after\s+\w|on\s+\w|in\s+\d+\s*(?:min|hour|day|week))\b/i;

const SNOOZE_REASONS = ["Low Energy", "Friction", "External Blocker", "Needs Context"];

type SpeechRec = {
  start: () => void;
  stop: () => void;
  onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onend: (() => void) | null;
  onerror: ((e: { error: string }) => void) | null;
  lang: string;
  interimResults: boolean;
  continuous: boolean;
};

function Dashboard() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [sideCollapsed, setSideCollapsed] = useState(false);
  const [input, setInput] = useState("");
  const [parsing, setParsing] = useState(false);
  const [slump, setSlump] = useState(false);
  const [listening, setListening] = useState(false);
  const [pendingClarification, setPendingClarification] = useState<string | null>(null);
  const [snoozeTarget, setSnoozeTarget] = useState<Task | null>(null);
  const [snoozeReason, setSnoozeReason] = useState("");
  const [showInfo, setShowInfo] = useState(false);
  const recogRef = useRef<SpeechRec | null>(null);
  const parse = useServerFn(parseUtterance);

  useEffect(() => {
    supabase
      .from("tasks")
      .select("id,title,column,meta")
      .order("created_at", { ascending: false })
      .then(({ data, error }) => {
        if (error) toast.error(error.message);
        else setTasks((data ?? []) as Task[]);
        setLoading(false);
      });
  }, []);

  const visible = (col: Column) => tasks.filter((t) => t.column === col);

  async function commitTask(utterance: string) {
    setParsing(true);
    try {
      const parsed = await parse({ data: { utterance } });
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) return;
      const { data, error } = await supabase
        .from("tasks")
        .insert({
          user_id: userData.user.id,
          title: parsed.title,
          column: parsed.column,
          meta: parsed.meta,
        })
        .select("id,title,column,meta")
        .single();
      if (error) throw error;
      setTasks((t) => [data as Task, ...t]);
      toast.success("Echo parsed your input", {
        description: `Filed under ${columnConfig[parsed.column].label}`,
      });
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setParsing(false);
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const v = input.trim();
    if (!v) return;

    // If awaiting clarification, merge time details with the original utterance.
    if (pendingClarification) {
      const merged = `${pendingClarification} — ${v}`;
      setInput("");
      setPendingClarification(null);
      await commitTask(merged);
      return;
    }

    // No temporal anchor → ask Echo's clarification instead of creating a card.
    if (!TEMPORAL_RE.test(v)) {
      setPendingClarification(v);
      setInput("");
      return;
    }

    setInput("");
    await commitTask(v);
  };

  const confirmSnooze = async () => {
    if (!snoozeTarget) return;
    const reason = snoozeReason.trim() || "Block reason logged";
    const id = snoozeTarget.id;
    const prev = tasks;
    setTasks((t) => t.filter((x) => x.id !== id));
    setSnoozeTarget(null);
    setSnoozeReason("");
    const { error } = await supabase.from("tasks").delete().eq("id", id);
    if (error) {
      setTasks(prev);
      toast.error(error.message);
      return;
    }
    toast.success("Barrier logged — guilt-free", {
      description: `Reason: ${reason}. Notifications suppressed without penalty.`,
    });
  };

  const toggleVoice = () => {
    const w = window as unknown as {
      SpeechRecognition?: new () => SpeechRec;
      webkitSpeechRecognition?: new () => SpeechRec;
    };
    const Ctor = w.SpeechRecognition ?? w.webkitSpeechRecognition;
    if (!Ctor) {
      toast.error("Voice capture not supported in this browser");
      return;
    }
    if (listening) {
      recogRef.current?.stop();
      return;
    }
    const r = new Ctor();
    r.lang = "en-US";
    r.interimResults = false;
    r.continuous = false;
    r.onresult = (e) => {
      const transcript = e.results[0][0].transcript;
      setInput(transcript);
    };
    r.onerror = (e) => toast.error(`Voice: ${e.error}`);
    r.onend = () => setListening(false);
    recogRef.current = r;
    setListening(true);
    r.start();
  };

  return (
    <div className="relative mx-auto max-w-7xl px-6 pb-44 pt-10">
      {/* Slump banner */}
      <div
        className={`overflow-hidden transition-all duration-500 ${
          slump ? "mb-6 max-h-96 opacity-100" : "max-h-0 opacity-0"
        }`}
      >
        <div className="relative rounded-2xl border border-pink-400/40 bg-gradient-to-r from-pink-500/15 via-violet-500/15 to-orange-500/15 p-6 shadow-[0_0_60px_-10px_rgba(236,72,153,0.45)]">
          <button
            onClick={() => setSlump(false)}
            className="absolute right-4 top-4 text-slate-400 hover:text-slate-100"
            aria-label="Dismiss"
          >
            <X className="h-4 w-4" />
          </button>
          <div className="flex items-start gap-4">
            <div className="rounded-full bg-pink-400/15 p-2.5">
              <Sparkles className="h-5 w-5 text-pink-300" />
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.25em] text-pink-300">
                Echo Flashback
              </p>
              <p className="mt-2 text-pretty text-base leading-relaxed text-slate-200">
                Take a deep breath. Your Vault remembers what you've already overcome. One small step
                at a time — you've broken harder roadblocks than this one.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-50">
            <span className="bg-gradient-to-r from-pink-500 via-orange-400 to-violet-500 bg-clip-text text-transparent">
              Priority Matrix
            </span>
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Three lenses. Zero forms. Voice or text — Echo parses it.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <span className="animate-pulse-soft inline-flex items-center gap-2 rounded-full border border-emerald-500/40 bg-emerald-500/10 px-3 py-1.5 text-xs font-medium text-emerald-300 shadow-[0_0_20px_-5px_rgba(16,185,129,0.35)]">
            🟢 Engine Status: Google Gemini Pro Active
          </span>
          <button
            onClick={() => setShowInfo(true)}
            className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-slate-700 bg-slate-900/60 text-slate-300 backdrop-blur-xl transition-colors hover:border-violet-400/60 hover:text-violet-300"
            aria-label="Architecture info"
          >
            <Code2 className="h-4 w-4" />
          </button>
        </div>
      </div>

      {loading ? (
        <div className="mt-12 flex items-center gap-2 text-sm text-slate-400">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading your matrix…
        </div>
      ) : (
        <div className="mt-8 grid gap-5 lg:grid-cols-3">
          {(["red", "yellow", "green"] as Column[]).map((col) => {
            const cfg = columnConfig[col];
            const collapsed = col === "green" && sideCollapsed;
            return (
              <section
                key={col}
                className={`rounded-2xl border p-5 backdrop-blur-xl ${cfg.section}`}
              >
                <header className="flex items-center justify-between">
                  <h2
                    className={`flex items-center gap-2 text-sm font-semibold uppercase tracking-[0.2em] ${cfg.accent}`}
                  >
                    <span className="text-base leading-none">{cfg.dot}</span>
                    {cfg.label}
                  </h2>
                  {col === "green" && (
                    <button
                      onClick={() => setSideCollapsed((v) => !v)}
                      className="rounded-full border border-emerald-500/40 p-1.5 text-emerald-300 transition-colors hover:border-emerald-400/70"
                      aria-label="Toggle"
                    >
                      <ChevronDown
                        className={`h-4 w-4 transition-transform ${collapsed ? "-rotate-90" : ""}`}
                      />
                    </button>
                  )}
                </header>
                <div
                  className={`mt-4 space-y-3 overflow-hidden transition-all duration-500 ${
                    collapsed ? "max-h-0 opacity-0" : "max-h-[2000px] opacity-100"
                  }`}
                >
                  {visible(col).length === 0 && (
                    <p className="text-xs text-slate-500">No tasks yet. Speak or type below.</p>
                  )}
                  {visible(col).map((t) => (
                    <div
                      key={t.id}
                      className={`group animate-fade-in rounded-2xl border p-4 backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:scale-[1.02] ${cfg.card}`}
                    >
                      <p className="text-sm font-medium text-slate-100">{t.title}</p>
                      {t.meta && <p className={`mt-1 text-xs ${cfg.meta}`}>{t.meta}</p>}
                      <button
                        onClick={() => setSnoozeTarget(t)}
                        className={`mt-3 text-xs font-medium transition-colors ${cfg.snooze}`}
                      >
                        Snooze with Reason →
                      </button>
                    </div>
                  ))}
                </div>
              </section>
            );
          })}
        </div>
      )}

      {/* Composer */}
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-slate-800/60 bg-[#090D16]/85 backdrop-blur-xl">
        <div className="mx-auto max-w-4xl px-6 py-4">
          {parsing && (
            <div className="mb-3 animate-fade-in rounded-2xl border border-pink-400/30 bg-pink-400/5 px-4 py-3">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-pink-300">
                Echo AI
              </p>
              <p className="mt-1 flex items-center gap-2 text-sm text-slate-200">
                <Loader2 className="h-3.5 w-3.5 animate-spin" /> Parsing intent, entities, and energy
                window…
              </p>
            </div>
          )}

          {pendingClarification && !parsing && (
            <div className="mb-3 animate-fade-in rounded-2xl border border-violet-400/40 bg-gradient-to-r from-violet-500/10 via-pink-500/10 to-orange-500/10 px-4 py-3 shadow-[0_0_40px_-10px_rgba(139,92,246,0.5)]">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-violet-300">
                Echo AI
              </p>
              <p className="mt-1 text-sm text-slate-100">
                I've noted that down! To defend this time safely, what day or time is{" "}
                <span className="font-semibold text-pink-300">"{pendingClarification}"</span> due?
              </p>
              <button
                onClick={() => setPendingClarification(null)}
                className="mt-2 text-xs text-slate-400 hover:text-slate-200"
              >
                Cancel
              </button>
            </div>
          )}

          <form
            onSubmit={handleSubmit}
            className="flex items-center gap-2 rounded-full border border-slate-800/80 bg-slate-900/60 p-2 backdrop-blur-xl focus-within:border-pink-400/60 focus-within:shadow-[0_0_30px_-5px_rgba(236,72,153,0.45)]"
          >
            <button
              type="button"
              onClick={toggleVoice}
              className={`relative inline-flex h-10 w-10 items-center justify-center rounded-full transition-colors ${
                listening
                  ? "bg-rose-500/20 text-rose-300"
                  : "bg-pink-400/10 text-pink-300 hover:bg-pink-400/20"
              }`}
              aria-label="Voice to task"
            >
              {listening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
              {listening && (
                <span className="absolute inset-0 animate-ping rounded-full border border-rose-400/40" />
              )}
            </button>
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              disabled={parsing}
              placeholder={
                pendingClarification
                  ? "Reply with a day or time (e.g. tomorrow 5pm)…"
                  : listening
                    ? "Listening…"
                    : "Tell Echo what's on your mind — voice or text"
              }
              className="flex-1 bg-transparent px-2 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none disabled:opacity-50"
            />
            <button
              type="submit"
              disabled={parsing || !input.trim()}
              className="inline-flex h-10 items-center gap-2 rounded-full bg-gradient-to-r from-pink-500 via-orange-400 to-violet-500 px-5 text-sm font-semibold text-slate-950 disabled:opacity-50"
            >
              <Send className="h-4 w-4" />
              Send
            </button>
          </form>
        </div>
      </div>

      <button
        onClick={() => setSlump((v) => !v)}
        className="fixed bottom-28 right-6 z-50 inline-flex items-center gap-2 rounded-full border border-orange-400/50 bg-orange-500/10 px-4 py-2.5 text-xs font-semibold text-orange-200 backdrop-blur-xl transition-all hover:scale-105 hover:border-orange-400/80 hover:shadow-[0_0_30px_-5px_rgba(249,115,22,0.6)]"
      >
        <AlertTriangle className="h-4 w-4" />
        Simulate Slump Trigger
      </button>

      {/* Snooze with Reason modal */}
      {snoozeTarget && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-6">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setSnoozeTarget(null)}
          />
          <GlassCard className="relative w-full max-w-md animate-fade-in border-violet-400/40 bg-slate-950/80 p-6 shadow-[0_0_60px_-10px_rgba(139,92,246,0.5)]">
            <button
              onClick={() => setSnoozeTarget(null)}
              className="absolute right-3 top-3 text-slate-400 hover:text-slate-100"
              aria-label="Close"
            >
              <X className="h-4 w-4" />
            </button>
            <p className="text-xs font-semibold uppercase tracking-[0.25em] text-violet-300">
              Snooze with Reason
            </p>
            <p className="mt-2 text-sm text-slate-300">
              What's blocking <span className="text-pink-300">"{snoozeTarget.title}"</span>? Echo logs
              it guilt-free.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {SNOOZE_REASONS.map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => setSnoozeReason(r)}
                  className={`rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${
                    snoozeReason === r
                      ? "border-pink-400/70 bg-pink-400/15 text-pink-200"
                      : "border-slate-700 text-slate-300 hover:border-violet-400/60 hover:text-violet-200"
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
            <input
              value={snoozeReason}
              onChange={(e) => setSnoozeReason(e.target.value)}
              placeholder="Or type your own reason…"
              className="mt-4 w-full rounded-xl border border-slate-700 bg-slate-900/60 px-3 py-2 text-sm text-slate-100 placeholder:text-slate-500 focus:border-pink-400/60 focus:outline-none"
            />
            <div className="mt-5 flex items-center justify-end gap-2">
              <button
                onClick={() => setSnoozeTarget(null)}
                className="rounded-full border border-slate-700 px-4 py-2 text-xs font-medium text-slate-300 hover:border-slate-500"
              >
                Cancel
              </button>
              <button
                onClick={confirmSnooze}
                className="rounded-full bg-gradient-to-r from-pink-500 via-orange-400 to-violet-500 px-5 py-2 text-xs font-semibold text-slate-950"
              >
                Log barrier &amp; snooze
              </button>
            </div>
          </GlassCard>
        </div>
      )}

      {/* Architecture Info Modal */}
      {showInfo && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-6">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setShowInfo(false)}
          />
          <GlassCard className="relative w-full max-w-lg animate-fade-in border-violet-400/40 bg-slate-950/80 p-6 shadow-[0_0_60px_-10px_rgba(139,92,246,0.5)]">
            <button
              onClick={() => setShowInfo(false)}
              className="absolute right-3 top-3 text-slate-400 hover:text-slate-100"
              aria-label="Close"
            >
              <X className="h-4 w-4" />
            </button>
            <p className="text-xs font-semibold uppercase tracking-[0.25em] text-violet-300">
              ECHO Pipeline
            </p>
            <h3 className="mt-1 text-lg font-bold text-slate-50">
              Powered by Google Cloud & AI Studio
            </h3>
            <div className="mt-5 space-y-4">
              <div className="rounded-xl border border-rose-500/30 bg-rose-950/30 p-4 backdrop-blur-xl">
                <p className="text-sm font-semibold text-pink-300">Gemini 1.5 Pro</p>
                <p className="mt-1 text-xs leading-relaxed text-slate-300">
                  Deep semantic understanding of natural language tasks with long-context reasoning and multi-step planning.
                </p>
              </div>
              <div className="rounded-xl border border-orange-500/30 bg-violet-950/30 p-4 backdrop-blur-xl">
                <p className="text-sm font-semibold text-orange-300">Google Cloud Speech-to-Text v2</p>
                <p className="mt-1 text-xs leading-relaxed text-slate-300">
                  Real-time voice transcription with punctuation, speaker diarization, and noise robustness.
                </p>
              </div>
              <div className="rounded-xl border border-emerald-500/30 bg-emerald-950/30 p-4 backdrop-blur-xl">
                <p className="text-sm font-semibold text-emerald-300">Google Workspace Sync</p>
                <p className="mt-1 text-xs leading-relaxed text-slate-300">
                  Seamless integration with Calendar, Tasks, and Docs for a unified productivity layer.
                </p>
              </div>
            </div>
          </GlassCard>
        </div>
      )}
    </div>
  );
}
