import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ShieldCheck, Lock, Loader2 } from "lucide-react";
import { GlassCard } from "@/components/echo/GlassCard";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/vault")({
  head: () => ({ meta: [{ title: "The Vault — ECHO" }] }),
  component: Vault,
});

type Entry = { id: string; date_label: string; text: string };

function Vault() {
  const [entries, setEntries] = useState<Entry[]>([]);
  const [draft, setDraft] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase
      .from("vault_entries")
      .select("id,date_label,text")
      .order("created_at", { ascending: false })
      .then(({ data, error }) => {
        if (error) toast.error(error.message);
        else setEntries((data ?? []) as Entry[]);
        setLoading(false);
      });
  }, []);

  const commit = async (e: React.FormEvent) => {
    e.preventDefault();
    const v = draft.trim();
    if (!v) return;
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) return;
    const date_label = new Date().toLocaleDateString(undefined, { month: "short", year: "numeric" });
    const { data, error } = await supabase
      .from("vault_entries")
      .insert({ user_id: u.user.id, text: v, date_label })
      .select("id,date_label,text")
      .single();
    if (error) return toast.error(error.message);
    setEntries((s) => [data as Entry, ...s]);
    setDraft("");
    toast.success("Committed to the Vault", { description: "Echo will pull from this when you need it." });
  };

  return (
    <div className="mx-auto max-w-5xl px-6 pb-24 pt-16">
      <header className="flex items-center gap-3">
        <span className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-cyan-400/30 bg-cyan-400/10">
          <Lock className="h-4 w-4 text-cyan-300" />
        </span>
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-50">The Anti-Doubt Vault</h1>
          <p className="text-sm text-slate-400">A private registry of proven wins. Echo recalls them when the slump hits.</p>
        </div>
      </header>

      <GlassCard className="mt-10 p-6">
        <form onSubmit={commit} className="space-y-3">
          <label className="text-xs font-semibold uppercase tracking-[0.25em] text-cyan-300">Add a breakthrough</label>
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            rows={3}
            placeholder="e.g. Led the client demo solo — won the renewal."
            className="w-full rounded-xl border border-slate-800/80 bg-slate-950/40 p-3 text-sm text-slate-100 placeholder:text-slate-500 focus:border-cyan-400/60 focus:outline-none"
          />
          <div className="flex justify-end">
            <button type="submit" className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 px-5 py-2 text-sm font-semibold text-slate-950">
              <ShieldCheck className="h-4 w-4" />
              Commit to Vault
            </button>
          </div>
        </form>
      </GlassCard>

      <div className="mt-10 space-y-4">
        <p className="text-xs font-semibold uppercase tracking-[0.25em] text-slate-500">
          Active Registry · {entries.length} entries
        </p>
        {loading && (
          <p className="flex items-center gap-2 text-sm text-slate-400">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading…
          </p>
        )}
        {!loading && entries.length === 0 && (
          <p className="text-sm text-slate-500">No breakthroughs yet. Commit your first above.</p>
        )}
        {entries.map((e) => (
          <GlassCard key={e.id} className="p-5">
            <p className="text-xs font-mono uppercase tracking-wider text-cyan-300/80">{e.date_label}</p>
            <p className="mt-2 text-sm leading-relaxed text-slate-200">{e.text}</p>
          </GlassCard>
        ))}
      </div>
    </div>
  );
}
