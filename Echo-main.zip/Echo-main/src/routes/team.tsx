import { createFileRoute } from "@tanstack/react-router";
import { Github, Mail, BookOpen, MessageCircle } from "lucide-react";
import { GlassCard } from "@/components/echo/GlassCard";

export const Route = createFileRoute("/team")({
  head: () => ({ meta: [{ title: "Team — ECHO" }] }),
  component: Team,
});

const cards = [
  { icon: Github, label: "Repository", value: "@developer/echo-core", href: "https://github.com/developer/echo-core" },
  { icon: Mail, label: "Support channel", value: "logs@echoai.dev", href: "mailto:logs@echoai.dev" },
  { icon: BookOpen, label: "Developer portal", value: "docs.echoai.dev", href: "#" },
  { icon: MessageCircle, label: "Community signal", value: "discord.echoai.dev", href: "#" },
];

function Team() {
  return (
    <div className="mx-auto max-w-5xl px-6 pb-24 pt-16">
      <header className="max-w-2xl">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-cyan-300">Crew · Channels</p>
        <h1 className="mt-3 text-4xl font-bold tracking-tight text-slate-50 md:text-5xl">
          Reach the resonance team
        </h1>
        <p className="mt-4 text-slate-400">
          Open source at the core. The signals below route directly to the people building Echo.
        </p>
      </header>

      <div className="mt-12 grid gap-5 md:grid-cols-2">
        {cards.map((c) => (
          <a key={c.label} href={c.href}>
            <GlassCard className="flex items-center gap-4 p-6">
              <span className="inline-flex h-12 w-12 items-center justify-center rounded-xl border border-cyan-400/30 bg-cyan-400/10">
                <c.icon className="h-5 w-5 text-cyan-300" />
              </span>
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.25em] text-slate-500">{c.label}</p>
                <p className="mt-1 font-mono text-sm text-slate-100">{c.value}</p>
              </div>
            </GlassCard>
          </a>
        ))}
      </div>
    </div>
  );
}
