import { Link, useNavigate } from "@tanstack/react-router";
import { Activity, LogOut } from "lucide-react";
import { useAuth } from "@/lib/use-auth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const publicLinks = [
  { to: "/", label: "Home" },
  { to: "/features", label: "Features" },
  { to: "/team", label: "Team" },
] as const;

const authedLinks = [
  { to: "/", label: "Home" },
  { to: "/dashboard", label: "Dashboard" },
  { to: "/features", label: "Features" },
  { to: "/vault", label: "Vault" },
  { to: "/team", label: "Team" },
] as const;

export function Navbar() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const links = user ? authedLinks : publicLinks;

  const signOut = async () => {
    await supabase.auth.signOut();
    toast.success("Signed out");
    navigate({ to: "/" });
  };

  return (
    <header className="sticky top-0 z-50 border-b border-slate-800/60 bg-[#090D16]/70 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
        <Link to="/" className="flex items-center gap-2">
          <span className="relative inline-flex h-8 w-8 items-center justify-center rounded-full border border-pink-400/50 bg-gradient-to-br from-pink-500/20 via-orange-500/20 to-violet-500/20">
            <Activity className="h-4 w-4 text-pink-300" />
            <span className="absolute inset-0 animate-ping rounded-full border border-pink-400/50" />
          </span>
          <span className="bg-gradient-to-r from-pink-500 via-orange-400 to-violet-500 bg-clip-text text-lg font-bold uppercase tracking-[0.3em] text-transparent">
            Echo
          </span>
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              activeOptions={{ exact: l.to === "/" }}
              activeProps={{ className: "text-cyan-300 bg-cyan-400/10 border-cyan-400/30" }}
              inactiveProps={{ className: "text-slate-400 hover:text-slate-100 border-transparent" }}
              className="rounded-full border px-4 py-1.5 text-sm font-medium transition-colors"
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          {loading ? null : user ? (
            <button
              onClick={signOut}
              className="inline-flex items-center gap-1.5 rounded-full border border-slate-700 px-4 py-1.5 text-sm font-medium text-slate-200 transition-colors hover:border-rose-400/60 hover:text-rose-200"
            >
              <LogOut className="h-3.5 w-3.5" />
              Sign out
            </button>
          ) : (
            <>
              <Link
                to="/auth"
                className="rounded-full border border-slate-700 px-4 py-1.5 text-sm font-medium text-slate-200 transition-colors hover:border-cyan-400/60 hover:text-cyan-200"
              >
                Sign Up
              </Link>
              <Link
                to="/auth"
                className="rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 px-4 py-1.5 text-sm font-semibold text-slate-950 shadow-[0_0_25px_-5px_rgba(34,211,238,0.6)] transition-all hover:shadow-[0_0_35px_-3px_rgba(34,211,238,0.8)]"
              >
                Login
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
