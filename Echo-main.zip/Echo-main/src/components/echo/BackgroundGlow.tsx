export function BackgroundGlow() {
  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-0 -z-10 overflow-hidden"
      style={{ backgroundColor: "#090D16" }}
    >
      {/* Violet bloom — top left */}
      <div
        className="absolute -top-48 -left-48 h-[640px] w-[640px] rounded-full opacity-50 blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(139,92,246,0.55), transparent 70%)" }}
      />
      {/* Bright pink — center right */}
      <div
        className="absolute top-1/4 -right-40 h-[720px] w-[720px] rounded-full opacity-45 blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(255,0,127,0.45), transparent 70%)" }}
      />
      {/* Deep crimson — mid */}
      <div
        className="absolute top-1/2 left-1/3 h-[560px] w-[560px] -translate-x-1/2 rounded-full opacity-35 blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(220,38,38,0.45), transparent 70%)" }}
      />
      {/* Bright orange — bottom right */}
      <div
        className="absolute -bottom-40 right-1/4 h-[600px] w-[600px] rounded-full opacity-40 blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(255,94,0,0.45), transparent 70%)" }}
      />
      {/* Emerald — bottom left */}
      <div
        className="absolute -bottom-48 -left-20 h-[560px] w-[560px] rounded-full opacity-35 blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(16,185,129,0.45), transparent 70%)" }}
      />
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "radial-gradient(circle at 1px 1px, rgba(255,255,255,0.6) 1px, transparent 0)",
          backgroundSize: "32px 32px",
        }}
      />
    </div>
  );
}
