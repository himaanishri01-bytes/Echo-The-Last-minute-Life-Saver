import { Github, Mail } from "lucide-react";

export function Footer() {
  return (
    <footer className="mt-24 border-t border-slate-800/60">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-6 py-8 text-sm text-slate-400 md:flex-row">
        <p className="uppercase tracking-[0.3em] text-slate-500">Echo · Resonance Engine</p>
        <div className="flex items-center gap-6">
          <a className="flex items-center gap-2 transition-colors hover:text-cyan-300" href="https://github.com/developer/echo-core">
            <Github className="h-4 w-4" /> @developer/echo-core
          </a>
          <a className="flex items-center gap-2 transition-colors hover:text-cyan-300" href="mailto:logs@echoai.dev">
            <Mail className="h-4 w-4" /> logs@echoai.dev
          </a>
        </div>
      </div>
    </footer>
  );
}
