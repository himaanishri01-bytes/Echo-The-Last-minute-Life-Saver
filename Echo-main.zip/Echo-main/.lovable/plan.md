# ECHO — Build Plan

A minimal, premium dark-mode multi-page React app for an AI productivity companion. Pure frontend (no backend/auth) — all interactions are local state + toasts.

## Stack & Conventions
- TanStack Start (existing template), Tailwind v4, shadcn components already available.
- Sonner for toasts (already in template).
- Lucide icons (Activity for soundwave pulse, Mic, Plus, Clock, etc.).
- All colors via existing semantic tokens + a few new ECHO tokens added to `src/styles.css` (deep midnight `#090D16`, cyan/teal/blue glows). No hardcoded `text-white` / `bg-black` in components.

## Routes (file-based under `src/routes/`)
- `index.tsx` → Home
- `dashboard.tsx` → Interactive Matrix Dashboard
- `features.tsx` → Features deep-dive
- `vault.tsx` → The Vault
- `team.tsx` → Team / Contact
- `__root.tsx` → adds dark class on html, persistent `<Navbar />` + `<Toaster />`, background gradient layer

## Shared Components (`src/components/echo/`)
- `Navbar.tsx` — sticky top bar; uppercase ECHO + pulsing Activity icon; nav links with active state (`activeProps`); Sign Up (outline) + Login (cyan→blue gradient) buttons.
- `BackgroundGlow.tsx` — fixed full-screen layer with radial cyan/teal/blue gradients on `#090D16`.
- `GlassCard.tsx` — reusable glassmorphic card: `bg-slate-900/40 backdrop-blur-xl border border-slate-800/80 rounded-2xl transition-all duration-300 hover:-translate-y-1 hover:scale-[1.02] hover:border-cyan-400/60 hover:shadow-[0_0_40px_-5px_theme(colors.cyan.500/40%)]`.
- `Footer.tsx` — GitHub @developer/echo-core + logs@echoai.dev.

## Home (`/`)
- Hero: massive headline "In the midst of chaos, your resilience echoes louder than the deadline.", subtitle on resilience → calm execution, glowing "Launch Workspace" button → `navigate({ to: "/dashboard" })`.
- 3-card feature grid using GlassCard: Zero-Form Input Engine, Dynamic Priority Matrix, The Anti-Doubt Vault (each with icon + short desc).
- Footer block.

## Dashboard (`/dashboard`)
State held in the route component:
- `tasks: { id, title, column: 'red'|'yellow'|'green', meta?: string }[]` with a couple of seed items per column.
- `sideQuestsCollapsed: boolean`.
- `pendingClarification: string | null` — when set, shows inline Echo AI chat bubble above input.
- `slumpOpen: boolean` — controls slide-down Echo Flashback banner.
- `snoozedIds: Set<string>` — hides task from view.

Columns (3-col grid, stack on mobile):
- 🔴 Non-Negotiables, 🟡 When I Have Energy, 🟢 Side Quests (header has chevron toggle that animates collapse of card list).
- Each task = GlassCard with title, optional meta line, and a small "Snooze with Reason" link → removes from list + `toast.success("Notifications suppressed without penalty.")`.

Bottom input panel (sticky-ish at bottom of page content):
- Mic icon button (left, ambient pulse), text input, send button.
- Submit logic:
  1. If `pendingClarification` is null: store input as `pendingClarification`, render chat bubble above input: *"Echo AI: I've noted that down! To defend this time safely, what day or time is this due?"*. Clear input.
  2. If `pendingClarification` is set: stitch `${pendingClarification} — ${followUp}` into a new task injected into Non-Negotiables (animate in via `animate-fade-in`), clear `pendingClarification`, `toast.success("Task locked into Non-Negotiables.")`.

Floating dev button (fixed bottom-right): "⚠️ Simulate Slump Trigger" → toggles slump banner that slides down from top of dashboard with Echo Flashback motivational copy (engineering capstone breakthrough example), with close button.

## Features (`/features`)
GlassCard sections explaining:
- Natural Language Tokenization Metrics
- Relative Date Parsing Parameters
- Prompt Context Tracking Windows
Each with a short technical paragraph and a couple of bullet "metrics" rows.

## Vault (`/vault`)
- Header: "The Anti-Doubt Vault".
- Local state list of breakthroughs (seeded with 2-3 examples).
- Form: textarea + "Commit to Vault" button → prepends to list, toast.
- Each entry rendered as a GlassCard with date + text.

## Team / Contact (`/team`)
- Cards: GitHub repo (@developer/echo-core), Support (logs@echoai.dev), Dev portal registry, Team access link.
- Each is a GlassCard with icon, label, and copy/visit affordance (static links).

## Styling Tokens (added to `src/styles.css`)
- Force dark by adding `dark` class on `<html>` in `__root.tsx` RootShell.
- New CSS vars under `.dark`: `--background: oklch(0.13 0.02 250)` approximating #090D16; tune `--card`, `--border` toward slate-800/80 feel.
- Keep tailwind utility classes (`bg-slate-900/40`, `border-slate-800/80`, `text-cyan-300`) for accent work — these are neutral palette utilities, not brand color overrides.

## Verification
After build, open `/`, `/dashboard`, `/features`, `/vault`, `/team` via Playwright; screenshot dashboard with/without slump banner; confirm clarification flow injects a task into Non-Negotiables.
